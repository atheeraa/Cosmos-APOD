package com.example.favor.cosmos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity LoaderManager.LoaderCallbacks<List<News>>{

public static final int LOADER_ID = 1;
public static final String REQUEST_URL =
        "https://api.nasa.gov/planetary/apod?api_key=t59T7J6yjULjNCqugFhbaPMIzwtjdex9L6BvGT9g";

        ListView mListView;
        TextView mTextView;
        NewsAdapter mAdapter;
        ProgressBar mProgressBar;


@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();

        mListView = (ListView) findViewById(R.id.list_view);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mTextView = (TextView) findViewById(R.id.text_view);

        if (networkInfo != null && networkInfo.isConnected()) {
        LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(NEWS_LOADER_ID, null, this);
        } else {
        mProgressBar.setVisibility(View.GONE);
        mTextView.setVisibility(View.VISIBLE);
        mTextView.setText(R.string.no_internet_text);
        }
}
