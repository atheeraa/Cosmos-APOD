package com.example.favor.cosmos;


public class list {
    private String mTitle;
    private String mDate;
    private String mUrl;
    private String mDesc;


    public News(String title, String date, String url, String desc) {
        mTitle = title;
        mDate = date;
        mUrl = url;
        mDesc = desc;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getUrl() {
        return mUrl;
    }

    public void setUrl(String url) {
        mUrl = url;
    }

    public String getDesc() {
        return mDesc;
    }

    public void setDesc(String desc) {
        mDesc = desc;
    }

}